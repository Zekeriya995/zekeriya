/* ═══════════════════════════════════════════════════════════════
   NEXUS PRO — MONITOR SUPERVISOR UPGRADE
   Smart Platform Supervisor + V3 Weight Feedback Loop
   ═══════════════════════════════════════════════════════════════

   HOW TO APPLY:
   1. Open app.js
   2. Add NEW VARIABLES (Section A) right after the monitorState init block (~line 145)
   3. Add NEW FUNCTIONS (Section B) right after saveFactorLog() (~line 155)
   4. REPLACE captureFactorSnapshot (Section C)
   5. MODIFY processTradeOutcome — add insertions (Section D)
   6. MODIFY autoTuneWeights — add V3 tuning at end (Section E)
   7. MODIFY renderTop3 — change weight caps (Section F)
   8. REPLACE renderMonPanel (Section G)
   9. REPLACE updateQACards (Section H)
   10. MINIMAL INSERTIONS in signalQualityGate, monitorTrades, init (Section I)
   11. APPEND new CSS to end of <style> (Section J)
   ═══════════════════════════════════════════════════════════════ */


/* ══════════════════════════════════════════════════════════════
   SECTION A: NEW VARIABLES
   Insert AFTER the monitorState initialization block
   (after the factorLog and saveFactorLog declarations)
   ══════════════════════════════════════════════════════════════ */

var DEFAULT_V3_WEIGHTS = {whale:25, smartMoney:20, technical:20, funding:15, timing:10, context:10};

/* Initialize V3 weights in monitorState if missing */
if (monitorState && !monitorState.v3weights) {
  monitorState.v3weights = JSON.parse(JSON.stringify(DEFAULT_V3_WEIGHTS));
  saveMonitor();
}
if (monitorState && !monitorState.v3factorStats) {
  monitorState.v3factorStats = {};
  saveMonitor();
}
if (monitorState && !monitorState.lastTuneTradeCount) {
  monitorState.lastTuneTradeCount = 0;
  saveMonitor();
}

/* ═══ SUPERVISOR DATA ═══ */
var supervisorData = {};
try { supervisorData = JSON.parse(localStorage.getItem('nxSupervisor') || '{}'); } catch(e) { supervisorData = {}; }
if (!supervisorData.whaleAudit) supervisorData.whaleAudit = [];
if (!supervisorData.scannerAudit) supervisorData.scannerAudit = [];
if (!supervisorData.gateLog) supervisorData.gateLog = [];
if (!supervisorData.dataQuality) supervisorData.dataQuality = [];
if (!supervisorData.dailyReport) supervisorData.dailyReport = null;
if (!supervisorData.lastCollect) supervisorData.lastCollect = 0;
if (!supervisorData.lastReport) supervisorData.lastReport = 0;

function saveSupervisor() {
  if (supervisorData.whaleAudit.length > 200) supervisorData.whaleAudit = supervisorData.whaleAudit.slice(-200);
  if (supervisorData.scannerAudit.length > 200) supervisorData.scannerAudit = supervisorData.scannerAudit.slice(-200);
  if (supervisorData.gateLog.length > 100) supervisorData.gateLog = supervisorData.gateLog.slice(-100);
  if (supervisorData.dataQuality.length > 48) supervisorData.dataQuality = supervisorData.dataQuality.slice(-48);
  try { localStorage.setItem('nxSupervisor', JSON.stringify(supervisorData)); } catch(e) {}
}


/* ══════════════════════════════════════════════════════════════
   SECTION B: NEW FUNCTIONS
   Insert AFTER saveFactorLog()
   ══════════════════════════════════════════════════════════════ */

/* ─── trackWhaleOutcome — called inside monitorTrades ─── */
function trackWhaleOutcome() {
  var now = Date.now();
  Object.keys(whaleWaves).forEach(function(sym) {
    var ww = whaleWaves[sym];
    if (!ww || !ww.waves || !ww.waves.length) return;
    if (!ww.engine) return;
    var d = T[sym];
    if (!d || !d.p) return;

    var existing = supervisorData.whaleAudit.filter(function(a) {
      return a.sym === sym && now - a.time < 86400000;
    });

    if (!existing.length) {
      var avgEntry = 0;
      try { var we = calcWhaleAvgEntry(sym); if (we > 0) avgEntry = we; } catch(e) {}
      supervisorData.whaleAudit.push({
        sym: sym,
        time: now,
        conf: ww.engine.confidence || 0,
        rank: ww.engine.rank || '',
        entryPrice: avgEntry || d.p,
        waves: ww.waves.length,
        snapshots: [{ t: now, p: d.p }],
        outcome: null
      });
    } else {
      var entry = existing[0];
      var lastSnap = entry.snapshots.length ? entry.snapshots[entry.snapshots.length - 1].t : 0;
      if (now - lastSnap >= 1800000) {
        entry.snapshots.push({ t: now, p: d.p });
        if (entry.snapshots.length > 48) entry.snapshots = entry.snapshots.slice(-48);
      }
      if (!entry.outcome && now - entry.time >= 14400000 && entry.entryPrice > 0) {
        var change = ((d.p - entry.entryPrice) / entry.entryPrice) * 100;
        entry.outcome = change >= 2 ? 'WIN' : change >= 0 ? 'NEUTRAL' : 'LOSS';
        entry.finalChange = change;
      }
    }
  });
  saveSupervisor();
}

/* ─── trackGateRejection — called inside signalQualityGate ─── */
function trackGateRejection(sym, type, results, pass) {
  if (pass) return;
  var failed = results.filter(function(r) { return !r.pass; }).map(function(r) { return r.name; });
  supervisorData.gateLog.push({
    sym: sym,
    type: type,
    time: Date.now(),
    failed: failed,
    price: T[sym] ? T[sym].p : 0,
    change: T[sym] ? T[sym].c : 0
  });
  saveSupervisor();
}

/* ─── supervisorCollect — runs every hour ─── */
function supervisorCollect() {
  var now = Date.now();
  var snapshot = {
    time: now,
    coins: Object.keys(T).length,
    fr: Object.keys(FR).length,
    oi: Object.keys(OI).length,
    ls: Object.keys(LS).length,
    topTraders: Object.keys(topTradersLS).length,
    frHist: Object.keys(frHistory).length,
    oiHist: Object.keys(oiHistory).length,
    cvd: Object.keys(aggCVD).length,
    depth: Object.keys(depthSnapshots).filter(function(s) { return depthSnapshots[s] && depthSnapshots[s].bids; }).length,
    taker: Object.keys(takerData).filter(function(s) { return takerData[s]; }).length,
    bitfinex: Object.keys(bitfinexMargin).length,
    hyperliquid: Object.keys(hyperliquidData).length,
    coinalyze: Object.keys(coinalyzeOI).length,
    cbp: Object.keys(CBP).length,
    whaleActive: Object.keys(whaleWaves).filter(function(s) { return whaleWaves[s] && whaleWaves[s].waves && whaleWaves[s].waves.length; }).length,
    scannerSignals: cache.scan ? cache.scan.length : 0,
    top3Shown: document.querySelectorAll('.top3-card').length,
    openTrades: activeTrades ? activeTrades.filter(function(t) { return t.status === 'OPEN'; }).length : 0,
    winRate: monitorState ? monitorState.perf.overallRate : 0,
    totalTrades: monitorState ? monitorState.perf.totalTrades : 0,
    btcChange: T.BTC ? T.BTC.c : 0,
    fgValue: fgValue || 50,
    dataAge: Math.round((now - lastDataTime) / 1000),
    apiRate: (connMetrics.apiOk + connMetrics.apiFail) > 0 ? Math.round(connMetrics.apiOk / (connMetrics.apiOk + connMetrics.apiFail) * 100) : 0
  };
  supervisorData.dataQuality.push(snapshot);
  supervisorData.lastCollect = now;
  saveSupervisor();
}

/* ─── supervisorDailyReport — runs every 24h ─── */
function supervisorDailyReport() {
  var now = Date.now();
  var day = 86400000;
  var ar = lang === 'ar';

  /* 1. Whale audit summary */
  var whaleRecent = supervisorData.whaleAudit.filter(function(a) { return now - a.time < day && a.outcome; });
  var whaleWins = whaleRecent.filter(function(a) { return a.outcome === 'WIN'; }).length;
  var whaleLosses = whaleRecent.filter(function(a) { return a.outcome === 'LOSS'; }).length;
  var whaleRate = whaleRecent.length > 0 ? Math.round(whaleWins / whaleRecent.length * 100) : 0;

  var diamondGold = whaleRecent.filter(function(a) { return a.conf >= 80; });
  var dgWins = diamondGold.filter(function(a) { return a.outcome === 'WIN'; }).length;
  var dgRate = diamondGold.length > 0 ? Math.round(dgWins / diamondGold.length * 100) : 0;

  /* 2. Scanner audit */
  var recentTrades = (typeof factorLog !== 'undefined' ? factorLog : []).filter(function(l) { return now - l.time < day; });
  var scanWins = recentTrades.filter(function(l) { return l.outcome === 'win' || l.outcome === 'partial'; }).length;
  var scanRate = recentTrades.length > 0 ? Math.round(scanWins / recentTrades.length * 100) : 0;

  var bestTrade = null, worstTrade = null;
  recentTrades.forEach(function(t) {
    if (!bestTrade || (t.pnl || 0) > (bestTrade.pnl || 0)) bestTrade = t;
    if (!worstTrade || (t.pnl || 0) < (worstTrade.pnl || 0)) worstTrade = t;
  });

  /* 3. VIP (Top 3) audit */
  var vipTrades = recentTrades.filter(function(t) { return t.conf >= 80; });
  var vipWins = vipTrades.filter(function(t) { return t.outcome === 'win' || t.outcome === 'partial'; }).length;
  var vipRate = vipTrades.length > 0 ? Math.round(vipWins / vipTrades.length * 100) : 0;

  /* 4. Gate audit */
  var gateRecent = supervisorData.gateLog.filter(function(g) { return now - g.time < day; });
  var gateCounts = {};
  gateRecent.forEach(function(g) {
    g.failed.forEach(function(f) {
      if (!gateCounts[f]) gateCounts[f] = { total: 0, coins: [] };
      gateCounts[f].total++;
      if (gateCounts[f].coins.indexOf(g.sym) === -1) gateCounts[f].coins.push(g.sym);
    });
  });

  /* 5. Data quality */
  var qualRecent = supervisorData.dataQuality.filter(function(q) { return now - q.time < day; });
  var avgApiRate = qualRecent.length > 0 ? Math.round(qualRecent.reduce(function(s, q) { return s + q.apiRate; }, 0) / qualRecent.length) : 0;
  var avgDataAge = qualRecent.length > 0 ? Math.round(qualRecent.reduce(function(s, q) { return s + q.dataAge; }, 0) / qualRecent.length) : 0;
  var disconnects = qualRecent.filter(function(q) { return q.coins < 50; }).length;

  /* 6. P&L summary */
  var totalPnl = recentTrades.reduce(function(s, t) { return s + (t.pnl || 0); }, 0);

  /* 7. Overall grade */
  var grade = 0;
  if (scanRate >= 70) grade += 30; else if (scanRate >= 50) grade += 20; else grade += 10;
  if (whaleRate >= 60) grade += 20; else if (whaleRate >= 40) grade += 10;
  if (avgApiRate >= 95) grade += 20; else if (avgApiRate >= 80) grade += 15; else grade += 5;
  if (totalPnl > 0) grade += 15; else if (totalPnl > -2) grade += 10; else grade += 5;
  if (disconnects === 0) grade += 15; else if (disconnects <= 2) grade += 10; else grade += 5;
  var gradeLabel = grade >= 85 ? 'A' : grade >= 70 ? 'B+' : grade >= 60 ? 'B' : grade >= 50 ? 'C' : 'D';

  /* 8. Recommendations */
  var recommendations = [];
  Object.keys(gateCounts).forEach(function(gate) {
    if (gateCounts[gate].total >= 3) {
      recommendations.push({
        type: 'info',
        text: (ar ? 'Gate "' + gate + '" blocked ' + gateCounts[gate].total + ' signals' : 'Gate "' + gate + '" blocked ' + gateCounts[gate].total + ' signals — verify blocks')
      });
    }
  });
  if (whaleRate < 50 && whaleRecent.length >= 3) {
    recommendations.push({ type: 'warn', text: ar ? 'Whale accuracy low (' + whaleRate + '%)' : 'Whale accuracy low (' + whaleRate + '%) — consider raising confidence threshold' });
  }
  if (scanRate >= 70) {
    recommendations.push({ type: 'good', text: ar ? 'Scanner excellent (' + scanRate + '%)' : 'Scanner performing well (' + scanRate + '%)' });
  }
  if (avgDataAge > 15) {
    recommendations.push({ type: 'warn', text: ar ? 'Data age high ' + avgDataAge + 's' : 'Average data age ' + avgDataAge + 's — check connection speed' });
  }
  if (disconnects > 3) {
    recommendations.push({ type: 'bad', text: ar ? 'Frequent disconnects (' + disconnects + 'x)' : 'Frequent disconnects (' + disconnects + 'x) — check PROXY server' });
  }

  var report = {
    time: now,
    grade: grade,
    gradeLabel: gradeLabel,
    totalTrades: recentTrades.length,
    scanWins: scanWins,
    scanRate: scanRate,
    bestTrade: bestTrade ? { sym: bestTrade.sym, pnl: bestTrade.pnl || 0 } : null,
    worstTrade: worstTrade ? { sym: worstTrade.sym, pnl: worstTrade.pnl || 0 } : null,
    totalPnl: totalPnl,
    vipTrades: vipTrades.length,
    vipWins: vipWins,
    vipRate: vipRate,
    whaleSignals: whaleRecent.length,
    whaleWins: whaleWins,
    whaleRate: whaleRate,
    dgRate: dgRate,
    dgCount: diamondGold.length,
    gateBlocks: gateRecent.length,
    gateCounts: gateCounts,
    avgApiRate: avgApiRate,
    avgDataAge: avgDataAge,
    disconnects: disconnects,
    recommendations: recommendations
  };

  supervisorData.dailyReport = report;
  supervisorData.lastReport = now;
  saveSupervisor();
  return report;
}

/* ─── renderDailyReport — popup display ─── */
function renderDailyReport() {
  var rpt = supervisorData.dailyReport;
  if (!rpt) { try { rpt = supervisorDailyReport(); } catch(e) { return; } }
  if (!rpt) return;
  var ar = lang === 'ar';
  var h = '';
  var gradeCol = rpt.grade >= 85 ? 'var(--up)' : rpt.grade >= 60 ? 'var(--warn)' : 'var(--dn)';

  h += '<div style="text-align:center;padding:20px 16px;background:var(--glass);border:1px solid var(--bdr);border-radius:16px;margin-bottom:12px">';
  h += '<div style="font-size:48px;font-weight:800;font-family:var(--fd);color:' + gradeCol + ';line-height:1">' + rpt.gradeLabel + '</div>';
  h += '<div style="font-size:12px;font-weight:700;color:' + gradeCol + ';margin-top:4px">' + (ar ? 'Daily Grade' : 'Daily Grade') + ' (' + rpt.grade + '/100)</div>';
  h += '<div style="font-size:10px;color:var(--t3);margin-top:4px">' + new Date(rpt.time).toLocaleString() + '</div></div>';

  h += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:12px">';
  h += '<div class="cd" style="padding:10px;text-align:center"><div style="font-family:var(--fm);font-size:16px;font-weight:800;color:' + (rpt.scanRate >= 60 ? 'var(--up)' : 'var(--warn)') + '">' + rpt.scanRate + '%</div><div style="font-size:8px;color:var(--t3)">Scanner</div></div>';
  h += '<div class="cd" style="padding:10px;text-align:center"><div style="font-family:var(--fm);font-size:16px;font-weight:800;color:' + (rpt.whaleRate >= 50 ? 'var(--up)' : 'var(--warn)') + '">' + rpt.whaleRate + '%</div><div style="font-size:8px;color:var(--t3)">Whales</div></div>';
  h += '<div class="cd" style="padding:10px;text-align:center"><div style="font-family:var(--fm);font-size:16px;font-weight:800;color:' + (rpt.totalPnl >= 0 ? 'var(--up)' : 'var(--dn)') + '">' + (rpt.totalPnl >= 0 ? '+' : '') + rpt.totalPnl.toFixed(1) + '%</div><div style="font-size:8px;color:var(--t3)">P&L</div></div>';
  h += '</div>';

  if (rpt.recommendations && rpt.recommendations.length) {
    h += '<div style="margin-bottom:8px">';
    rpt.recommendations.forEach(function(r) {
      var ic = r.type === 'good' ? '✅' : r.type === 'warn' ? '⚠️' : r.type === 'bad' ? '🔴' : 'ℹ️';
      var bg = r.type === 'good' ? 'rgba(0,255,136,.06)' : r.type === 'warn' ? 'rgba(255,184,0,.06)' : r.type === 'bad' ? 'rgba(255,56,96,.06)' : 'rgba(91,156,255,.06)';
      h += '<div style="display:flex;align-items:center;gap:6px;padding:8px 10px;background:' + bg + ';border-radius:8px;margin-bottom:4px;font-size:10px;color:var(--t1)">' + ic + ' ' + r.text + '</div>';
    });
    h += '</div>';
  }

  try {
    showPopup('📊', ar ? 'Daily Report' : 'Daily Report', rpt.gradeLabel + ' — ' + rpt.scanRate + '% scanner — ' + rpt.whaleRate + '% whales');
  } catch(e) {}

  var el = document.getElementById('dailyReportPopup');
  if (el) { el.innerHTML = h; el.style.display = 'block'; }
}


/* ══════════════════════════════════════════════════════════════
   SECTION C: REPLACE captureFactorSnapshot
   Find the existing captureFactorSnapshot function and replace entirely
   ══════════════════════════════════════════════════════════════ */

function captureFactorSnapshot(sym) {
  var d = T[sym]; if (!d) return null;
  var fr = FR[sym];
  var ls = LS[sym];
  var oi = OI[sym];
  var ww = whaleWaves[sym];
  var wConf = ww && ww.engine ? ww.engine.confidence : 0;
  var cvd = null; try { cvd = analyzeCVD(sym); } catch(e) {}

  var snapshot = {
    sym: sym,
    time: Date.now(),
    hour: new Date().getUTCHours(),
    price: d.p,
    change24h: d.c,
    factors: {
      trend:      d.c > 0,
      whales:     wConf >= 40,
      rsi:        true,
      fr:         fr ? fr.rate < 0 : false,
      oi:         oi ? oi > 0 : false,
      vol:        d.v > 5e7,
      macd:       true,
      confluence: true,
      structure:  true
    },
    /* ═══ NEW: V3 scoring categories ═══ */
    v3categories: {
      whale: wConf >= 40 || (ww && ww.waves && ww.waves.length >= 2),
      smartMoney: (function() {
        var sm = false;
        try {
          if (topTradersLS[sym] && topTradersLS[sym].accounts && topTradersLS[sym].accounts.length) {
            var tl = topTradersLS[sym].accounts[topTradersLS[sym].accounts.length - 1];
            if (tl.long > 0.55) sm = true;
          }
        } catch(e) {}
        try {
          if (!sm && CBP[sym] && T[sym] && T[sym].p > 0 && ((CBP[sym] - T[sym].p) / T[sym].p) > 0.002) sm = true;
        } catch(e) {}
        return sm;
      })(),
      technical: (function() {
        var tech = false;
        try { var cv = analyzeCVD(sym); if (cv && (cv.divergence === 'BULLISH' || cv.trend === 'BUYING')) tech = true; } catch(e) {}
        try { if (!tech) { var vp = calcVPIN(sym); if (vp && vp.vpin > 0.5) tech = true; } } catch(e) {}
        return tech;
      })(),
      funding: (fr && fr.rate < -0.005) || (function() {
        try {
          if (frHistory[sym] && frHistory[sym].length >= 4) {
            var negC = frHistory[sym].filter(function(x) { return x.rate < -0.005; }).length;
            if (negC >= 3) return true;
          }
        } catch(e) {}
        return false;
      })(),
      timing: (function() {
        /* Check if signal was detected within 15 min */
        try {
          if (sigHist[sym] && sigHist[sym].time && (Date.now() - sigHist[sym].time) < 900000) return true;
        } catch(e) {}
        return false;
      })(),
      context: (function() {
        var ctx = false;
        try {
          if (monitorState && monitorState.coinStats && monitorState.coinStats[sym] && monitorState.coinStats[sym].rate >= 55) ctx = true;
        } catch(e) {}
        if (!ctx && T.BTC && T.BTC.c > 1) ctx = true;
        return ctx;
      })()
    },
    raw: {
      frRate: fr ? fr.rate : 0,
      lsRatio: ls ? ls.ratio : 1,
      wConf: wConf,
      cvdSignal: cvd ? cvd.divergence : 'NONE',
      fgValue: fgValue,
      btcChange: T.BTC ? T.BTC.c : 0,
      volume: d.v,
      change: d.c
    }
  };
  return snapshot;
}


/* ══════════════════════════════════════════════════════════════
   SECTION D: INSERTIONS for processTradeOutcome
   Add these lines AFTER the existing factorKeys.forEach loop
   (after the line: fs.winRate = fs.total > 0 ? ... )
   And BEFORE the confBucket line
   ══════════════════════════════════════════════════════════════ */

/*
FIND this block in processTradeOutcome:
---
  factorKeys.forEach(function(key) {
    if (snap.factors[key]) {
      var fs = monitorState.factorStats[key];
      fs.total++;
      if (isWin || isPartial) fs.wins++;
      else fs.losses++;
      fs.winRate = fs.total > 0 ? Math.round((fs.wins / fs.total) * 100) : 0;
    }
  });
---

ADD IMMEDIATELY AFTER that forEach block:
*/

// --- START INSERT in processTradeOutcome (after factorKeys.forEach) ---

  // Track V3 categories
  if (snap.v3categories) {
    if (!monitorState.v3factorStats) monitorState.v3factorStats = {};
    var v3Keys = Object.keys(snap.v3categories);
    v3Keys.forEach(function(key) {
      if (snap.v3categories[key]) {
        if (!monitorState.v3factorStats[key]) monitorState.v3factorStats[key] = {wins:0, losses:0, total:0, winRate:0};
        var fs = monitorState.v3factorStats[key];
        fs.total++;
        if (isWin || isPartial) fs.wins++;
        else fs.losses++;
        fs.winRate = fs.total > 0 ? Math.round((fs.wins / fs.total) * 100) : 0;
      }
    });
  }

// --- END INSERT ---

/*
ALSO ADD at the very end of processTradeOutcome,
BEFORE the final saveMonitor() and saveFactorLog() calls:
*/

// --- START INSERT (5-trade auto-tune trigger) ---

  // 5-trade auto-tune trigger (replaces weekly timer)
  var tradesSinceLastTune = monitorState.perf.totalTrades - (monitorState.lastTuneTradeCount || 0);
  if (tradesSinceLastTune >= 5) {
    try {
      autoTuneWeights();
      monitorState.lastTuneTradeCount = monitorState.perf.totalTrades;
    } catch(e) {}
  }

// --- END INSERT ---


/* ══════════════════════════════════════════════════════════════
   SECTION E: INSERTION for autoTuneWeights
   Add this block at the END of autoTuneWeights, BEFORE the
   final saveMonitor() call (before the addVLog line)
   ══════════════════════════════════════════════════════════════ */

// --- START INSERT in autoTuneWeights (before saveMonitor) ---

  // Tune V3 category weights (used by renderTop3)
  if (monitorState.v3factorStats && monitorState.v3weights) {
    var v3def = DEFAULT_V3_WEIGHTS;
    var v3w = monitorState.v3weights;
    Object.keys(v3def).forEach(function(key) {
      var stat = monitorState.v3factorStats[key];
      if (stat && stat.total >= 5) {
        var rate = stat.winRate;
        var defW = v3def[key];
        var minW = defW * 0.5;
        var maxW = defW * 2.0;
        if (rate >= 70) {
          v3w[key] = Math.min(maxW, Math.round(v3w[key] * 1.15 * 100) / 100);
        } else if (rate >= 55) {
          v3w[key] = Math.round((v3w[key] + (defW - v3w[key]) * 0.1) * 100) / 100;
        } else if (rate < 45) {
          v3w[key] = Math.max(minW, Math.round(v3w[key] * 0.85 * 100) / 100);
        }
      }
    });
  }

// --- END INSERT ---


/* ══════════════════════════════════════════════════════════════
   SECTION F: CHANGES in renderTop3
   At the START of the scoring section, ADD the V3W variable.
   Then change each category's Math.min clamp to use learned weights.
   ══════════════════════════════════════════════════════════════ */

/*
FIND in renderTop3, right before:
    var whaleScore=0;

ADD BEFORE IT:
*/

    // READ learned weights from monitorState (falls back to defaults)
    var V3W = monitorState && monitorState.v3weights ? monitorState.v3weights : DEFAULT_V3_WEIGHTS;
    var whaleMax = V3W.whale || 25;
    var smartMax = V3W.smartMoney || 20;
    var techMax = V3W.technical || 20;
    var fundMax = V3W.funding || 15;
    var timeMax = V3W.timing || 10;
    var ctxMax = V3W.context || 10;

/*
THEN CHANGE each clamp line:

FIND:  whaleScore=Math.max(-5,Math.min(25,whaleScore));
REPLACE: whaleScore=Math.max(-5,Math.min(whaleMax,whaleScore));

FIND:  smartScore=Math.min(20,smartScore);
REPLACE: smartScore=Math.min(smartMax,smartScore);

FIND:  techScore=Math.min(20,techScore);
REPLACE: techScore=Math.min(techMax,techScore);

FIND:  fundScore=Math.max(-4,Math.min(15,fundScore));
REPLACE: fundScore=Math.max(-4,Math.min(fundMax,fundScore));

FIND:  timeScore=Math.max(-3,Math.min(10,timeScore));
REPLACE: timeScore=Math.max(-3,Math.min(timeMax,timeScore));

FIND:  ctxScore=Math.max(-5,Math.min(10,ctxScore));
REPLACE: ctxScore=Math.max(-5,Math.min(ctxMax,ctxScore));
*/


/* ══════════════════════════════════════════════════════════════
   SECTION G: REPLACE renderMonPanel — COMPLETE REWRITE (18 sections)
   Find the existing renderMonPanel function and replace entirely
   ══════════════════════════════════════════════════════════════ */

function renderMonPanel() {
  var el = document.getElementById('monPanel'); if (!el) return;
  var ar = lang === 'ar'; var h = '';
  var total = connMetrics.apiOk + connMetrics.apiFail;
  var apiRate = total > 0 ? Math.round(connMetrics.apiOk / total * 100) : 0;
  var ms = monitorState || {perf:{overallRate:0,totalTrades:0,totalWins:0,totalLosses:0,bestHour:-1,worstHour:-1},factorStats:{},confCalib:{},hourStats:{},coinStats:{},coinBlacklist:[],weights:{},minConf:55,failPatterns:[],v3weights:DEFAULT_V3_WEIGHTS,v3factorStats:{}};
  var perf = ms.perf;
  var perfCol = perf.overallRate >= 65 ? 'var(--up)' : perf.overallRate >= 50 ? 'var(--warn)' : 'var(--dn)';
  var mkt; try { mkt = detectMarketDanger(); } catch(e) { mkt = {level:'safe',dangerous:false,reasons:[]}; }
  var mktIc = mkt.level === 'safe' ? '🟢' : mkt.level === 'caution' ? '🟡' : '🔴';
  var mktCol = mkt.level === 'safe' ? 'var(--up)' : mkt.level === 'caution' ? 'var(--warn)' : 'var(--dn)';
  var tkC = Object.keys(T).length, frC = Object.keys(FR).length, oiC = Object.keys(OI).length;

  /* ═══ SECTION 1: DAILY REPORT CARD ═══ */
  var rpt = supervisorData.dailyReport;
  if (rpt) {
    var gradeCol = rpt.grade >= 85 ? 'var(--up)' : rpt.grade >= 60 ? 'var(--warn)' : 'var(--dn)';
    h += '<div class="sv-report-card" onclick="try{renderDailyReport()}catch(e){}">';
    h += '<div class="sv-grade" style="color:' + gradeCol + '">' + rpt.gradeLabel + '</div>';
    h += '<div style="font-size:11px;font-weight:700;color:' + gradeCol + '">' + (ar ? 'Daily Grade' : 'Daily Grade') + ' (' + rpt.grade + '/100)</div>';
    h += '<div class="sv-report-stats">';
    h += '<div class="sv-rs"><span class="sv-rs-v" style="color:' + (rpt.scanRate >= 60 ? 'var(--up)' : 'var(--warn)') + '">' + rpt.scanRate + '%</span><span class="sv-rs-l">Scanner</span></div>';
    h += '<div class="sv-rs"><span class="sv-rs-v" style="color:' + (rpt.whaleRate >= 50 ? 'var(--up)' : 'var(--warn)') + '">' + rpt.whaleRate + '%</span><span class="sv-rs-l">' + (ar ? 'Whales' : 'Whales') + '</span></div>';
    h += '<div class="sv-rs"><span class="sv-rs-v" style="color:' + (rpt.vipRate >= 60 ? 'var(--up)' : 'var(--warn)') + '">' + rpt.vipRate + '%</span><span class="sv-rs-l">VIP</span></div>';
    h += '<div class="sv-rs"><span class="sv-rs-v" style="color:' + (rpt.totalPnl >= 0 ? 'var(--up)' : 'var(--dn)') + '">' + (rpt.totalPnl >= 0 ? '+' : '') + rpt.totalPnl.toFixed(1) + '%</span><span class="sv-rs-l">P&L</span></div>';
    h += '</div>';
    h += '<div style="font-size:8px;color:var(--t3);margin-top:6px">' + new Date(rpt.time).toLocaleString() + ' — ' + (ar ? 'Tap for details' : 'Tap for full report') + '</div>';
    h += '</div>';
  }

  /* ═══ SECTION 2: LIVE P&L DASHBOARD ═══ */
  var openTrades = activeTrades ? activeTrades.filter(function(t) { return t.status === 'OPEN'; }) : [];
  h += '<div class="sv-sec-title">💰 ' + (ar ? 'Live P&L' : 'Live P&L') + '</div>';
  if (openTrades.length) {
    var totalUnrealized = 0;
    h += '<div class="cd" style="padding:8px">';
    openTrades.forEach(function(tr) {
      var pnl = tr.pnl || 0;
      totalUnrealized += pnl;
      var pnlCol = pnl >= 2 ? 'var(--up)' : pnl >= 0 ? 'var(--warn)' : 'var(--dn)';
      h += '<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 4px;border-bottom:1px solid var(--bdr)">';
      h += '<div><span style="font-weight:700;font-size:11px;color:var(--t0)">' + tr.sym + '</span>';
      h += '<span style="font-size:9px;color:var(--t3);margin:0 6px">@ ' + fP(tr.entry) + ' → ' + fP(tr.curPrice || 0) + '</span></div>';
      h += '<div style="font-family:var(--fm);font-weight:700;font-size:11px;color:' + pnlCol + '">' + (pnl >= 0 ? '+' : '') + pnl.toFixed(2) + '%</div>';
      h += '</div>';
    });
    var totalCol = totalUnrealized >= 0 ? 'var(--up)' : 'var(--dn)';
    h += '<div style="display:flex;justify-content:space-between;padding:8px 4px 4px;font-size:12px;font-weight:800">';
    h += '<span style="color:var(--t1)">' + (ar ? 'Total' : 'Total') + ' (' + openTrades.length + ')</span>';
    h += '<span style="color:' + totalCol + ';font-family:var(--fm)">' + (totalUnrealized >= 0 ? '+' : '') + totalUnrealized.toFixed(2) + '%</span>';
    h += '</div></div>';
  } else {
    h += '<div class="cd sv-empty">' + (ar ? 'No open trades' : 'No open trades') + '</div>';
  }

  /* ═══ SECTION 3: SIGNAL PIPELINE STATUS ═══ */
  var scanCount = cache.scan ? cache.scan.length : 0;
  var top3Count = 0; try { top3Count = document.querySelectorAll('.top3-card').length; } catch(e) {}
  h += '<div class="sv-sec-title">🔬 ' + (ar ? 'Signal Pipeline' : 'Signal Pipeline') + '</div>';
  h += '<div class="sv-pipeline">';
  h += '<div class="sv-pip-step"><div class="sv-pip-v">' + tkC + '</div><div class="sv-pip-l">' + (ar ? 'Coins' : 'Coins') + '</div></div>';
  h += '<div class="sv-pip-arr">→</div>';
  h += '<div class="sv-pip-step"><div class="sv-pip-v">' + scanCount + '</div><div class="sv-pip-l">' + (ar ? 'Signals' : 'Signals') + '</div></div>';
  h += '<div class="sv-pip-arr">→</div>';
  h += '<div class="sv-pip-step"><div class="sv-pip-v" style="color:var(--neon)">' + top3Count + '</div><div class="sv-pip-l">Top 3</div></div>';
  h += '<div class="sv-pip-arr">→</div>';
  h += '<div class="sv-pip-step"><div class="sv-pip-v" style="color:var(--ultra)">' + openTrades.length + '</div><div class="sv-pip-l">' + (ar ? 'Trades' : 'Trades') + '</div></div>';
  h += '</div>';

  /* ═══ SECTION 4: DATA FRESHNESS MONITOR ═══ */
  h += '<div class="sv-sec-title">📡 ' + (ar ? 'Data Freshness' : 'Data Freshness') + '</div>';
  h += '<div class="cd" style="padding:8px">';
  var dataAge = Math.round((Date.now() - lastDataTime) / 1000);
  var ageCol = dataAge < 8 ? 'var(--up)' : dataAge < 20 ? 'var(--warn)' : 'var(--dn)';

  function dfRow(name, count, status) {
    var col = count > 0 ? 'var(--up)' : 'var(--dn)';
    var st = count > 0 ? '✅' : '❌';
    return '<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 2px;border-bottom:1px solid var(--bdr);font-size:10px">' +
      '<span style="color:var(--t2)">' + name + '</span>' +
      '<span style="font-family:var(--fm);font-weight:700;color:' + col + '">' + st + ' ' + count + '</span></div>';
  }

  h += '<div style="font-size:9px;font-weight:700;color:var(--t3);padding:2px 0;text-transform:uppercase;letter-spacing:1px">PROXY (' + dataAge + 's ' + (ar ? 'ago' : 'ago') + ')</div>';
  h += dfRow('Prices (T)', tkC, tkC > 0);
  h += dfRow('Funding Rate', frC, frC > 0);
  h += dfRow('Open Interest', oiC, oiC > 0);
  h += dfRow('Long/Short', Object.keys(LS).length, Object.keys(LS).length > 0);

  h += '<div style="font-size:9px;font-weight:700;color:var(--t3);padding:6px 0 2px;text-transform:uppercase;letter-spacing:1px">BINANCE ADVANCED</div>';
  h += dfRow('Top Traders L/S', Object.keys(topTradersLS).length, Object.keys(topTradersLS).length > 0);
  h += dfRow('FR History', Object.keys(frHistory).length, Object.keys(frHistory).length > 0);
  h += dfRow('OI History', Object.keys(oiHistory).length, Object.keys(oiHistory).length > 0);
  h += dfRow('Aggregated CVD', Object.keys(aggCVD).length, Object.keys(aggCVD).length > 0);

  h += '<div style="font-size:9px;font-weight:700;color:var(--t3);padding:6px 0 2px;text-transform:uppercase;letter-spacing:1px">MULTI-EXCHANGE</div>';
  h += dfRow('Bitfinex Margin', Object.keys(bitfinexMargin).length, Object.keys(bitfinexMargin).length > 0);
  h += dfRow('Hyperliquid', Object.keys(hyperliquidData).length, Object.keys(hyperliquidData).length > 0);
  h += dfRow('Coinalyze OI', Object.keys(coinalyzeOI).length, Object.keys(coinalyzeOI).length > 0);
  h += dfRow('Coinalyze FR', Object.keys(coinalyzeFR).length, Object.keys(coinalyzeFR).length > 0);

  h += '<div style="font-size:9px;font-weight:700;color:var(--t3);padding:6px 0 2px;text-transform:uppercase;letter-spacing:1px">OTHER</div>';
  h += dfRow('Coinbase (CBP)', Object.keys(CBP).length, Object.keys(CBP).length > 0);
  var depC = Object.keys(depthSnapshots).filter(function(s) { return depthSnapshots[s] && depthSnapshots[s].bids; }).length;
  h += dfRow('Order Book', depC, depC > 0);
  var tkDC = Object.keys(takerData).filter(function(s) { return takerData[s]; }).length;
  h += dfRow('Taker Data', tkDC, tkDC > 0);
  h += dfRow('Book Tickers', Object.keys(bookTickers).length, Object.keys(bookTickers).length > 0);
  var stableC = typeof stablecoinData !== 'undefined' ? Object.keys(stablecoinData).length : 0;
  h += dfRow('Stablecoin Data', stableC, stableC > 0);
  var unlockC = typeof tokenUnlocks !== 'undefined' && tokenUnlocks ? tokenUnlocks.length : 0;
  h += dfRow('Token Unlocks', unlockC, unlockC > 0);
  var newsC = typeof newsSentiment !== 'undefined' && newsSentiment ? (newsSentiment.total || 0) : 0;
  h += dfRow('News Sentiment', newsC, newsC > 0);
  h += '</div>';

  /* ═══ SECTION 5: MULTI-EXCHANGE HEALTH RADAR ═══ */
  h += '<div class="sv-sec-title">🌐 ' + (ar ? 'Exchange Health' : 'Exchange Health') + '</div>';
  h += '<div class="sv-exchange-grid">';
  var exchanges = [
    {name:'Binance Spot', ok: tkC > 0, count: tkC},
    {name:'Binance Futures', ok: frC > 0, count: frC},
    {name:'Bybit', ok: Object.keys(coinalyzeOI).length > 0 || frC > 10, count: Object.keys(coinalyzeOI).length},
    {name:'Coinbase', ok: Object.keys(CBP).length > 0, count: Object.keys(CBP).length},
    {name:'Bitfinex', ok: Object.keys(bitfinexMargin).length > 0, count: Object.keys(bitfinexMargin).length},
    {name:'Hyperliquid', ok: Object.keys(hyperliquidData).length > 0, count: Object.keys(hyperliquidData).length},
    {name:'Coinalyze', ok: Object.keys(coinalyzeOI).length > 0, count: Object.keys(coinalyzeOI).length}
  ];
  exchanges.forEach(function(ex) {
    h += '<div class="sv-ex-item" style="border-color:' + (ex.ok ? 'rgba(0,255,136,.1)' : 'rgba(255,56,96,.08)') + '">';
    h += '<span style="font-size:8px;font-weight:700;color:var(--t1)">' + ex.name + '</span>';
    h += '<span style="font-size:9px;font-family:var(--fm);font-weight:700;color:' + (ex.ok ? 'var(--up)' : 'var(--dn)') + '">' + (ex.ok ? '✅ ' + ex.count : '❌') + '</span>';
    h += '</div>';
  });
  h += '</div>';

  /* ═══ SECTION 6: WHALE ACTIVITY SUMMARY ═══ */
  var whC = Object.keys(whaleWaves).filter(function(s) { return whaleWaves[s] && whaleWaves[s].waves && whaleWaves[s].waves.length; }).length;
  h += '<div class="sv-sec-title">🐋 ' + (ar ? 'Whale Activity' : 'Whale Activity') + ' <span style="font-size:9px;padding:2px 6px;border-radius:5px;background:rgba(0,255,136,.1);color:var(--up)">' + whC + ' active</span></div>';
  if (whC > 0) {
    var whaleArr = Object.entries(whaleWaves).filter(function(e) {
      return e[1] && e[1].waves && e[1].waves.length && e[1].engine;
    }).sort(function(a, b) {
      return (b[1].engine.confidence || 0) - (a[1].engine.confidence || 0);
    }).slice(0, 3);

    var totalWhaleInflow = 0;
    Object.keys(whaleWaves).forEach(function(s) {
      if (whaleWaves[s] && whaleWaves[s].totalBuy) totalWhaleInflow += whaleWaves[s].totalBuy;
    });
    h += '<div style="font-size:10px;color:var(--t2);margin-bottom:6px">' + (ar ? 'Total Inflow: ' : 'Total Inflow: ') + '<b style="color:var(--neon)">' + fmt(totalWhaleInflow) + '</b></div>';
    h += '<div class="cd" style="padding:8px">';
    whaleArr.forEach(function(e) {
      var s = e[0], ww = e[1];
      var pnl = null; try { pnl = calcWhalePnL(s); } catch(ex) {}
      var pnlStr = pnl ? ((pnl.pct >= 0 ? '+' : '') + pnl.pct.toFixed(1) + '%') : '--';
      var pnlCol = pnl ? (pnl.pct >= 2 ? 'var(--up)' : pnl.pct >= 0 ? 'var(--warn)' : 'var(--dn)') : 'var(--t3)';
      h += '<div style="display:flex;justify-content:space-between;align-items:center;padding:5px 2px;border-bottom:1px solid var(--bdr)">';
      h += '<div><span style="font-weight:700;font-size:11px;color:var(--t0)">' + s + '</span>';
      h += ' <span style="font-size:8px;color:var(--neon)">' + (ww.engine.rank || '') + ' ' + ww.engine.confidence + '%</span></div>';
      h += '<span style="font-family:var(--fm);font-size:10px;font-weight:700;color:' + pnlCol + '">' + pnlStr + '</span>';
      h += '</div>';
    });
    h += '</div>';
  } else {
    h += '<div class="cd sv-empty">' + (ar ? 'No whale activity' : 'No whale activity') + '</div>';
  }

  /* ═══ SECTION 7: MARKET MOOD ═══ */
  h += '<div class="sv-sec-title">🧠 ' + (ar ? 'Market Mood' : 'Market Mood') + '</div>';
  var allCoins = Object.values(T);
  var greenPct = allCoins.length > 0 ? Math.round(allCoins.filter(function(x) { return x.c > 0; }).length / allCoins.length * 100) : 50;
  var moodScore = 50;
  /* FG */
  moodScore += (fgValue - 50) * 0.3;
  /* Green coins */
  moodScore += (greenPct - 50) * 0.2;
  /* BTC */
  var btcChg = T.BTC ? T.BTC.c : 0;
  moodScore += btcChg * 2;
  /* News */
  if (typeof newsSentiment !== 'undefined' && newsSentiment && newsSentiment.score) {
    moodScore += (newsSentiment.score - 50) * 0.15;
  }
  /* Stablecoin flow */
  if (typeof stablecoinData !== 'undefined' && stablecoinData && stablecoinData['USDT'] && stablecoinData['USDT'].change7d) {
    moodScore += stablecoinData['USDT'].change7d * 3;
  }
  moodScore = Math.max(0, Math.min(100, Math.round(moodScore)));
  var moodCol = moodScore >= 65 ? 'var(--up)' : moodScore >= 40 ? 'var(--warn)' : 'var(--dn)';
  var moodLabel = moodScore >= 75 ? (ar ? 'Greedy' : 'Greedy') : moodScore >= 55 ? (ar ? 'Optimistic' : 'Optimistic') : moodScore >= 40 ? (ar ? 'Neutral' : 'Neutral') : moodScore >= 25 ? (ar ? 'Fearful' : 'Fearful') : (ar ? 'Panic' : 'Panic');
  h += '<div class="cd" style="padding:12px;text-align:center">';
  h += '<div style="font-family:var(--fd);font-size:36px;font-weight:800;color:' + moodCol + '">' + moodScore + '</div>';
  h += '<div style="font-size:11px;font-weight:700;color:' + moodCol + '">' + moodLabel + '</div>';
  h += '<div style="height:5px;background:linear-gradient(90deg,var(--dn),var(--warn),var(--up));border-radius:3px;margin:8px 0;position:relative"><div style="position:absolute;top:-4px;left:' + moodScore + '%;width:12px;height:12px;background:var(--t0);border-radius:50%;border:2px solid var(--bg);transform:translateX(-50%)"></div></div>';
  h += '<div style="display:flex;justify-content:space-between;font-size:8px;color:var(--t3)">';
  h += '<span>FG: ' + fgValue + '</span><span>BTC: ' + (btcChg >= 0 ? '+' : '') + btcChg.toFixed(1) + '%</span><span>Green: ' + greenPct + '%</span>';
  h += '</div></div>';

  /* ═══ SECTION 8: V3 SCORING CATEGORY PERFORMANCE ═══ */
  h += '<div class="sv-sec-title">📊 ' + (ar ? 'V3 Categories' : 'V3 Category Performance') + '</div>';
  h += '<div class="cd" style="padding:10px">';
  var v3fs = ms.v3factorStats || {};
  var v3cats = ['whale', 'smartMoney', 'technical', 'funding', 'timing', 'context'];
  var v3icons = {whale:'🐋', smartMoney:'💼', technical:'📈', funding:'💰', timing:'⏰', context:'🌍'};
  var hasV3Data = false;
  v3cats.forEach(function(key) {
    var stat = v3fs[key];
    var wr = stat ? stat.winRate : 0;
    var total = stat ? stat.total : 0;
    if (total > 0) hasV3Data = true;
    var wC = total === 0 ? 'var(--t3)' : wr >= 65 ? 'var(--up)' : wr >= 45 ? 'var(--warn)' : 'var(--dn)';
    var wgt = ms.v3weights ? (ms.v3weights[key] || DEFAULT_V3_WEIGHTS[key]) : DEFAULT_V3_WEIGHTS[key];
    var defWgt = DEFAULT_V3_WEIGHTS[key];
    var wgtDiff = wgt !== defWgt;
    h += '<div style="display:flex;align-items:center;padding:5px 0;border-bottom:1px solid var(--bdr);font-size:11px">';
    h += '<span style="min-width:18px">' + (v3icons[key] || '') + '</span>';
    h += '<span style="font-weight:700;min-width:70px">' + key + '</span>';
    h += '<div style="flex:1;height:5px;background:rgba(56,72,96,.1);border-radius:3px;margin:0 6px;overflow:hidden"><div style="height:100%;width:' + Math.min(100, wr) + '%;border-radius:3px;background:' + wC + '"></div></div>';
    h += '<span style="font-family:var(--fm);font-weight:700;color:' + wC + ';min-width:32px;text-align:right">' + (total > 0 ? wr + '%' : '--') + '</span>';
    h += '<span style="font-family:var(--fm);font-size:8px;color:var(--t3);min-width:30px;text-align:right">' + (total > 0 ? stat.wins + '/' + total : '') + '</span>';
    if (wgtDiff) {
      h += '<span style="font-size:7px;color:var(--neon);min-width:20px;text-align:right" title="Learned weight">' + wgt + '</span>';
    }
    h += '</div>';
  });
  if (!hasV3Data) {
    h += '<div style="color:var(--t3);font-size:10px;text-align:center;padding:6px">' + (ar ? 'Need trades' : 'Need trades for V3 data') + '</div>';
  }
  h += '</div>';

  /* ═══ SECTION 9: WIN/LOSS STREAK + DAILY P&L ═══ */
  h += '<div class="sv-sec-title">📈 ' + (ar ? 'Streaks & P&L' : 'Streak & P&L') + '</div>';
  h += '<div class="cd" style="padding:10px">';
  var logs = factorLog || [];
  var streak = 0, maxStreak = 0, curType = '';
  var dayPnl = 0, weekPnl = 0;
  var now = Date.now();
  var last10 = logs.slice(-10).reverse();
  last10.forEach(function(l, i) {
    if (i === 0) { curType = (l.outcome === 'win' || l.outcome === 'partial') ? 'W' : 'L'; streak = 1; }
    else {
      var thisType = (l.outcome === 'win' || l.outcome === 'partial') ? 'W' : 'L';
      if (thisType === curType) streak++;
    }
    if (streak > maxStreak) maxStreak = streak;
  });
  logs.forEach(function(l) {
    if (now - l.time < 86400000) dayPnl += (l.pnl || 0);
    if (now - l.time < 604800000) weekPnl += (l.pnl || 0);
  });
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:11px">';
  h += '<span style="color:var(--t2)">' + (ar ? 'Current Streak' : 'Current Streak') + '</span>';
  h += '<span style="font-family:var(--fm);font-weight:700;color:' + (curType === 'W' ? 'var(--up)' : 'var(--dn)') + '">' + streak + ' ' + curType + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:11px;border-bottom:1px solid var(--bdr)">';
  h += '<span style="color:var(--t2)">' + (ar ? 'Best Streak' : 'Best Streak') + '</span>';
  h += '<span style="font-family:var(--fm);font-weight:700">' + maxStreak + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:11px">';
  h += '<span style="color:var(--t2)">' + (ar ? "Today P&L" : "Today's P&L") + '</span>';
  h += '<span style="font-family:var(--fm);font-weight:700;color:' + (dayPnl >= 0 ? 'var(--up)' : 'var(--dn)') + '">' + (dayPnl >= 0 ? '+' : '') + dayPnl.toFixed(1) + '%</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;font-size:11px">';
  h += '<span style="color:var(--t2)">' + (ar ? 'Week P&L' : 'Week P&L') + '</span>';
  h += '<span style="font-family:var(--fm);font-weight:700;color:' + (weekPnl >= 0 ? 'var(--up)' : 'var(--dn)') + '">' + (weekPnl >= 0 ? '+' : '') + weekPnl.toFixed(1) + '%</span></div>';
  /* Last 10 */
  if (last10.length) {
    h += '<div style="display:flex;gap:3px;margin-top:6px;justify-content:center">';
    last10.forEach(function(l) {
      var isW = l.outcome === 'win' || l.outcome === 'partial';
      h += '<div style="width:20px;height:20px;border-radius:4px;background:' + (isW ? 'rgba(0,255,136,.15)' : 'rgba(255,56,96,.15)') + ';display:grid;place-items:center;font-size:9px;font-weight:700;color:' + (isW ? 'var(--up)' : 'var(--dn)') + '">' + (isW ? 'W' : 'L') + '</div>';
    });
    h += '</div>';
  }
  h += '</div>';

  /* ═══ SECTION 10: HOUR PERFORMANCE GRID ═══ */
  h += '<div class="sv-sec-title">🕐 ' + (ar ? 'Hours' : 'Hour Grid') + '</div>';
  h += '<div class="cd" style="padding:10px"><div style="display:flex;flex-wrap:wrap;gap:2px">';
  for (var hr = 0; hr < 24; hr++) {
    var hs = ms.hourStats[String(hr)];
    var rate = hs ? hs.rate : -1;
    var bg = rate < 0 ? 'var(--bg2)' : rate >= 60 ? 'rgba(0,255,136,.15)' : rate >= 40 ? 'rgba(255,184,0,.15)' : 'rgba(255,56,96,.15)';
    var cl = rate < 0 ? 'var(--t3)' : rate >= 60 ? 'var(--up)' : rate >= 40 ? 'var(--warn)' : 'var(--dn)';
    h += '<div style="width:26px;padding:3px 1px;background:' + bg + ';border-radius:4px;text-align:center"><div style="font-size:7px;color:var(--t3)">' + String(hr).padStart(2, '0') + '</div><div style="font-size:8px;font-weight:700;font-family:var(--fm);color:' + cl + '">' + (rate >= 0 ? rate + '%' : '--') + '</div></div>';
  }
  h += '</div>';
  if (perf.bestHour >= 0) {
    h += '<div style="font-size:10px;margin-top:6px;color:var(--t2)">🏆 ' + (ar ? 'Best: ' : 'Best: ') + '<b style="color:var(--up)">' + perf.bestHour + ':00</b>' + (perf.worstHour >= 0 ? ' — ' + (ar ? 'Worst: ' : 'Worst: ') + '<b style="color:var(--dn)">' + perf.worstHour + ':00</b>' : '') + '</div>';
  }
  h += '</div>';

  /* ═══ SECTION 11: COIN PERFORMANCE + BLACKLIST ═══ */
  var coins = Object.entries(ms.coinStats).sort(function(a, b) { return (b[1].rate || 0) - (a[1].rate || 0); });
  if (coins.length) {
    h += '<div class="sv-sec-title">🪙 ' + (ar ? 'Coins' : 'Coin Performance') + '</div>';
    h += '<div class="cd" style="padding:10px">';
    coins.forEach(function(e) {
      var s = e[0], c = e[1];
      var cl = c.rate >= 65 ? 'var(--up)' : c.rate >= 45 ? 'var(--warn)' : 'var(--dn)';
      h += '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--bdr);font-size:11px"><span style="font-weight:700">' + s + '</span><span style="font-family:var(--fm);font-weight:700;color:' + cl + '">' + c.rate + '%</span><span style="font-size:9px;color:var(--t3)">' + c.wins + '/' + c.total + '</span></div>';
    });
    h += '</div>';
  }
  /* Blacklist */
  h += '<div class="sv-sec-title">🚫 ' + (ar ? 'Blacklist' : 'Blacklist') + '</div>';
  if (ms.coinBlacklist && ms.coinBlacklist.length) {
    h += '<div style="display:flex;gap:4px;flex-wrap:wrap">';
    ms.coinBlacklist.forEach(function(s) { h += '<span style="padding:5px 12px;background:var(--dd);border:1px solid rgba(255,56,96,.1);border-radius:8px;font-size:11px;font-weight:700;color:var(--dn)">' + s + '</span>'; });
    h += '</div>';
  } else {
    h += '<div style="padding:6px;text-align:center;font-size:11px;color:var(--up)">✅ ' + (ar ? 'All clean' : 'All clean') + '</div>';
  }

  /* ═══ SECTION 12: GATE REJECTION LOG ═══ */
  h += '<div class="sv-sec-title">🚧 ' + (ar ? 'Gate Rejections' : 'Gate Rejections') + '</div>';
  var gLog = supervisorData.gateLog || [];
  if (gLog.length) {
    h += '<div class="cd" style="padding:8px;max-height:150px;overflow-y:auto">';
    gLog.slice(-10).reverse().forEach(function(g) {
      var age = Date.now() - g.time;
      var agoTxt = age < 60000 ? 'now' : age < 3600000 ? Math.floor(age / 60000) + 'm' : Math.floor(age / 3600000) + 'h';
      h += '<div style="display:flex;align-items:center;gap:6px;padding:5px 2px;border-bottom:1px solid var(--bdr);font-size:10px">';
      h += '<span style="font-weight:700;color:var(--t0);min-width:36px">' + g.sym + '</span>';
      h += '<span style="flex:1;color:var(--dn)">' + g.failed.join(', ') + '</span>';
      h += '<span style="font-family:var(--fm);font-size:8px;color:var(--t3)">' + agoTxt + '</span>';
      h += '</div>';
    });
    h += '</div>';
  } else {
    h += '<div class="cd sv-empty">' + (ar ? 'No rejections' : 'No gate rejections') + '</div>';
  }

  /* ═══ SECTION 13: TOKEN UNLOCK CALENDAR ═══ */
  h += '<div class="sv-sec-title">🔓 ' + (ar ? 'Token Unlocks' : 'Token Unlocks') + '</div>';
  if (typeof tokenUnlocks !== 'undefined' && tokenUnlocks && tokenUnlocks.length) {
    var nowDate = new Date();
    var tier1Unlocks = tokenUnlocks.filter(function(u) {
      if (!u || !u.sym) return false;
      return TIER1.has(u.sym);
    }).slice(0, 8);
    if (tier1Unlocks.length) {
      h += '<div class="cd" style="padding:8px">';
      tier1Unlocks.forEach(function(u) {
        var days = Math.round((new Date(u.date) - nowDate) / 86400000);
        var daysCol = days <= 3 ? 'var(--dn)' : days <= 7 ? 'var(--warn)' : 'var(--t2)';
        h += '<div style="display:flex;justify-content:space-between;padding:4px 2px;border-bottom:1px solid var(--bdr);font-size:10px">';
        h += '<span style="font-weight:700;color:var(--t0)">' + u.sym + '</span>';
        h += '<span style="color:var(--t2)">' + fmt(u.amount || 0) + '</span>';
        h += '<span style="font-family:var(--fm);font-weight:700;color:' + daysCol + '">' + (days <= 0 ? (ar ? 'Today!' : 'Today!') : days + 'd') + '</span>';
        h += '</div>';
      });
      h += '</div>';
    } else {
      h += '<div class="cd sv-empty">' + (ar ? 'No TIER1 unlocks' : 'No upcoming TIER1 unlocks') + '</div>';
    }
  } else {
    h += '<div class="cd sv-empty">' + (ar ? 'No data' : 'No unlock data') + '</div>';
  }

  /* ═══ SECTION 14: CONFIDENCE CALIBRATION ═══ */
  h += '<div class="sv-sec-title">🎯 ' + (ar ? 'Confidence' : 'Confidence Calibration') + '</div>';
  h += '<div class="cd" style="padding:10px">';
  var bk = Object.keys(ms.confCalib).sort();
  if (bk.length) {
    bk.forEach(function(b) {
      var c = ms.confCalib[b];
      var cl = c.realRate >= 65 ? 'var(--up)' : c.realRate >= 45 ? 'var(--warn)' : 'var(--dn)';
      h += '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--bdr);font-size:11px"><span style="color:var(--t2)">Conf ' + b + '%</span><span style="font-family:var(--fm);font-weight:700;color:' + cl + '">' + c.realRate + '%</span><span style="font-size:9px;color:var(--t3)">(' + c.wins + '/' + c.total + ')</span></div>';
    });
  } else {
    h += '<div style="color:var(--t3);font-size:11px;text-align:center;padding:8px">' + (ar ? 'Need 5+ trades' : 'Need 5+ trades') + '</div>';
  }
  h += '</div>';

  /* ═══ SECTION 15: FAIL PATTERNS ═══ */
  if (ms.failPatterns && ms.failPatterns.length) {
    h += '<div class="sv-sec-title">⚠️ ' + (ar ? 'Fail Patterns' : 'Fail Patterns') + '</div>';
    h += '<div class="cd" style="padding:10px">';
    ms.failPatterns.slice(0, 5).forEach(function(p) {
      h += '<div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--bdr);font-size:11px"><span>' + p.label + '</span><span style="font-family:var(--fm);font-weight:700;color:var(--dn)">' + p.failRate + '%</span></div>';
    });
    h += '</div>';
  }

  /* ═══ SECTION 16: SELF-IMPROVEMENT REPORT ═══ */
  h += '<div class="sv-sec-title">🧠 ' + (ar ? 'Self-Improvement' : 'Self-Improvement') + '</div>';
  h += '<div class="cd" style="padding:10px;font-size:11px">';
  var lastTuneDate = ms.lastTune ? new Date(ms.lastTune).toLocaleString() : (ar ? 'Never' : 'Never');
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">' + (ar ? 'Last Tune' : 'Last Tune') + '</span><span style="font-family:var(--fm);font-weight:600">' + lastTuneDate + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">' + (ar ? 'Min Conf' : 'Min Confidence') + '</span><span style="font-family:var(--fm);font-weight:700;color:var(--warn)">' + ms.minConf + '%</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">' + (ar ? 'Auto-Tune Trigger' : 'Auto-Tune') + '</span><span style="font-family:var(--fm);font-weight:600">Every 5 trades</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0"><span style="color:var(--t2)">' + (ar ? 'Best Factor' : 'Best Factor') + '</span><span style="font-weight:700;color:var(--up)">' + (perf.bestFactor || '--') + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0"><span style="color:var(--t2)">' + (ar ? 'Worst Factor' : 'Worst Factor') + '</span><span style="font-weight:700;color:var(--dn)">' + (perf.worstFactor || '--') + '</span></div>';
  /* Old 9 factor weights */
  h += '<div style="font-size:9px;color:var(--t3);margin-top:6px;text-transform:uppercase;letter-spacing:1px">Old Factor Weights:</div>';
  var wKeys = Object.keys(ms.weights || {});
  if (wKeys.length) {
    h += '<div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:4px">';
    wKeys.forEach(function(k) {
      h += '<span style="font-size:8px;font-family:var(--fm);padding:2px 6px;background:var(--bg2);border-radius:4px;color:var(--t2)">' + k + ':' + (ms.weights[k] || 0).toFixed(1) + '</span>';
    });
    h += '</div>';
  }
  h += '</div>';

  /* ═══ SECTION 17: SMART RECOMMENDATIONS ═══ */
  if (rpt && rpt.recommendations && rpt.recommendations.length) {
    h += '<div class="sv-sec-title">💡 ' + (ar ? 'Recommendations' : 'Smart Recommendations') + '</div>';
    rpt.recommendations.forEach(function(r) {
      var ic = r.type === 'good' ? '✅' : r.type === 'warn' ? '⚠️' : r.type === 'bad' ? '🔴' : 'ℹ️';
      var bg = r.type === 'good' ? 'rgba(0,255,136,.06)' : r.type === 'warn' ? 'rgba(255,184,0,.06)' : r.type === 'bad' ? 'rgba(255,56,96,.06)' : 'rgba(91,156,255,.06)';
      h += '<div style="display:flex;align-items:center;gap:6px;padding:8px 10px;background:' + bg + ';border:1px solid var(--bdr);border-radius:10px;margin-bottom:4px;font-size:10px;color:var(--t1)">' + ic + ' ' + r.text + '</div>';
    });
  }

  /* ═══ SECTION 18: SYSTEM INFO ═══ */
  h += '<div class="sv-sec-title">🏥 ' + (ar ? 'System' : 'System Info') + '</div>';
  h += '<div class="cd" style="padding:10px;font-size:11px">';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">Coins</span><span style="font-family:var(--fm);font-weight:700;color:var(--neon)">' + tkC + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">FR / OI / LS</span><span style="font-family:var(--fm);font-weight:700">' + frC + ' / ' + oiC + ' / ' + Object.keys(LS).length + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">Min Conf</span><span style="font-family:var(--fm);font-weight:700;color:var(--warn)">' + ms.minConf + '%</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">Data Source</span><span style="font-family:var(--fm);font-weight:700;color:var(--neon)">Proxy Server</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">API Rate</span><span style="font-family:var(--fm);font-weight:700;color:' + (apiRate >= 90 ? 'var(--up)' : 'var(--warn)') + '">' + apiRate + '%</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid var(--bdr)"><span style="color:var(--t2)">WL Size</span><span style="font-family:var(--fm);font-weight:700">' + WL.length + '</span></div>';
  h += '<div style="display:flex;justify-content:space-between;padding:4px 0"><span style="color:var(--t2)">Version</span><span style="font-family:var(--fm);font-weight:700">V10 + Supervisor</span></div>';
  h += '</div>';

  /* Supervisor collection status */
  var lastCol = supervisorData.lastCollect || 0;
  var colAge = Date.now() - lastCol;
  var colTxt = lastCol === 0 ? 'Never' : colAge < 3600000 ? Math.round(colAge / 60000) + 'm ago' : Math.round(colAge / 3600000) + 'h ago';
  h += '<div style="text-align:center;font-size:8px;color:var(--t3);margin-top:8px">🔄 Supervisor: last collect ' + colTxt + ' — report ' + (supervisorData.lastReport ? new Date(supervisorData.lastReport).toLocaleDateString() : 'Never') + '</div>';

  el.innerHTML = h;
}


/* ══════════════════════════════════════════════════════════════
   SECTION H: REPLACE updateQACards
   ══════════════════════════════════════════════════════════════ */

function updateQACards() {
  try {
    var allC = Object.values(T);
    var greenPct = allC.length ? Math.round(allC.filter(function(x) { return x.c > 0; }).length / allC.length * 100) : 0;
    var hmEl = document.getElementById('qaHM');
    if (hmEl) { hmEl.textContent = greenPct + '%'; hmEl.style.color = greenPct > 55 ? 'var(--up)' : greenPct < 40 ? 'var(--dn)' : 'var(--warn)'; }
    var favEl = document.getElementById('qaFav');
    if (favEl) favEl.textContent = favorites.length + (lang === 'ar' ? ' coins' : ' coins');
    var alEl = document.getElementById('qaAlerts');
    if (alEl) { var c = notifHist ? notifHist.length : 0; alEl.innerHTML = c > 0 ? c + ' ' + (lang === 'ar' ? 'new' : 'new') + '<span style="display:inline-block;width:5px;height:5px;border-radius:50%;background:var(--dn);margin-right:3px;animation:pls 1s infinite"></span>' : '0'; }

    /* ═══ SUPERVISOR GRADE on QA monitor card ═══ */
    var monEl = document.getElementById('qaMon');
    if (monEl) {
      var rpt = supervisorData.dailyReport;
      if (rpt && rpt.gradeLabel) {
        var gradeCol = rpt.grade >= 85 ? 'var(--up)' : rpt.grade >= 60 ? 'var(--warn)' : 'var(--dn)';
        monEl.innerHTML = '<span style="font-size:14px;font-weight:800;color:' + gradeCol + '">' + rpt.gradeLabel + '</span><span style="font-size:8px;color:var(--t3)"> (' + rpt.grade + ')</span>';
      } else {
        var q = getConnQuality();
        monEl.textContent = q + '%';
        monEl.style.color = q >= 80 ? 'var(--up)' : q >= 50 ? 'var(--warn)' : 'var(--dn)';
      }
    }
  } catch(e) {}
}


/* ══════════════════════════════════════════════════════════════
   SECTION I: MINIMAL INSERTIONS
   These are single-line insertions in existing functions
   ══════════════════════════════════════════════════════════════ */

/*
──────────────────────────────────────────────
1. In signalQualityGate — add ONE line BEFORE the final return statement

FIND:
  return { pass: pass, results: results, marketDanger: mkt, failPattern: failPat };

ADD BEFORE IT:
  try { trackGateRejection(sym, type, results, pass); } catch(e) {}

──────────────────────────────────────────────
2. In monitorTrades — add ONE line at the end, BEFORE saveTrades()

FIND:
  saveTrades()}

CHANGE TO:
  try { trackWhaleOutcome(); } catch(e) {}
  saveTrades()}

──────────────────────────────────────────────
3. In init() — add after the existing setInterval blocks:

  // Supervisor hourly collection
  setInterval(function() { try { supervisorCollect(); } catch(e) {} }, 3600000);
  // Supervisor daily report (every 24h)
  setInterval(function() { try { supervisorDailyReport(); } catch(e) {} }, 86400000);
  // Run first collection after 30 seconds
  setTimeout(function() { try { supervisorCollect(); } catch(e) {} }, 30000);
  // Generate first daily report after 60 seconds (if none exists)
  setTimeout(function() { try { if (!supervisorData.dailyReport) supervisorDailyReport(); } catch(e) {} }, 60000);
──────────────────────────────────────────────
*/


/* ══════════════════════════════════════════════════════════════
   SECTION J: NEW CSS
   APPEND to end of <style> block in index.html
   ══════════════════════════════════════════════════════════════ */

/*

.sv-report-card{text-align:center;padding:16px;background:var(--glass);backdrop-filter:var(--gb);border:1.5px solid rgba(0,255,136,.08);border-radius:16px;margin-bottom:12px;cursor:pointer;transition:border-color .2s}
.sv-report-card:active{border-color:var(--neon)}
.sv-grade{font-family:var(--fd);font-size:52px;font-weight:800;line-height:1}
.sv-report-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:10px}
.sv-rs{background:var(--bg2);border-radius:8px;padding:6px 4px;text-align:center}
.sv-rs-v{font-family:var(--fm);font-size:13px;font-weight:700;display:block}
.sv-rs-l{font-size:7px;color:var(--t3);font-family:var(--fm);text-transform:uppercase;letter-spacing:.5px}
.sv-sec-title{font-weight:800;font-size:13px;color:var(--t1);margin:16px 0 8px;display:flex;align-items:center;gap:6px}
.sv-sec-title::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,var(--bdr-a),transparent)}
.sv-pipeline{display:flex;align-items:center;justify-content:center;gap:4px;padding:12px;background:var(--glass);border:1px solid var(--bdr);border-radius:12px;margin-bottom:8px}
.sv-pip-step{text-align:center;min-width:44px}
.sv-pip-v{font-family:var(--fm);font-size:18px;font-weight:800;color:var(--t0)}
.sv-pip-l{font-size:8px;color:var(--t3);font-family:var(--fm)}
.sv-pip-arr{font-size:12px;color:var(--t3);margin:0 2px}
.sv-exchange-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:4px;margin-bottom:8px}
.sv-ex-item{display:flex;justify-content:space-between;align-items:center;padding:6px 8px;background:var(--glass);border:1px solid var(--bdr);border-radius:8px}
.sv-empty{text-align:center;font-size:10px;color:var(--t3);padding:10px}
#dailyReportPopup{display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:300;background:rgba(0,0,0,.7);backdrop-filter:blur(10px);padding:20px;overflow-y:auto}
#dailyReportPopup>div{max-width:500px;margin:0 auto}

*/
